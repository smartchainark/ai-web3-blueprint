#!/usr/bin/env python3
"""
访谈协作写作 - 状态追踪辅助脚本

用于在访谈过程中追踪收集到的素材要素
"""

import json
from dataclasses import dataclass, asdict
from typing import List, Optional
from datetime import datetime

@dataclass
class InterviewState:
    """访谈状态追踪"""
    topic: str = ""
    topic_type: str = ""  # 热点事件/个人经历/观点输出
    round_count: int = 0
    
    # 四要素收集状态
    conflicts: List[str] = None
    emotions: List[str] = None
    insights: List[str] = None
    details: List[str] = None
    
    # 金句素材
    quotes: List[str] = None
    
    # 目标平台
    target_platform: str = ""
    
    # 核心观点
    core_viewpoint: str = ""
    
    def __post_init__(self):
        self.conflicts = self.conflicts or []
        self.emotions = self.emotions or []
        self.insights = self.insights or []
        self.details = self.details or []
        self.quotes = self.quotes or []
    
    def add_conflict(self, content: str):
        """添加冲突要素"""
        self.conflicts.append(content)
    
    def add_emotion(self, content: str):
        """添加情绪要素"""
        self.emotions.append(content)
    
    def add_insight(self, content: str):
        """添加洞察要素"""
        self.insights.append(content)
    
    def add_detail(self, content: str):
        """添加细节要素"""
        self.details.append(content)
    
    def add_quote(self, content: str):
        """添加金句素材"""
        self.quotes.append(content)
    
    def check_readiness(self) -> dict:
        """检查是否收集到足够素材"""
        return {
            "has_conflict": len(self.conflicts) > 0,
            "has_emotion": len(self.emotions) > 0,
            "has_insight": len(self.insights) > 0,
            "has_detail": len(self.details) > 0,
            "has_quote": len(self.quotes) > 0,
            "has_core_viewpoint": bool(self.core_viewpoint),
            "is_ready": all([
                len(self.conflicts) > 0,
                len(self.emotions) > 0,
                len(self.insights) > 0 or len(self.details) > 0,
                bool(self.core_viewpoint)
            ])
        }
    
    def get_missing_elements(self) -> List[str]:
        """获取缺失的要素"""
        missing = []
        if not self.conflicts:
            missing.append("冲突/转折")
        if not self.emotions:
            missing.append("情绪/感受")
        if not self.insights:
            missing.append("洞察/观点")
        if not self.details:
            missing.append("具体细节")
        return missing
    
    def suggest_next_question(self) -> str:
        """根据缺失要素建议下一个问题"""
        missing = self.get_missing_elements()
        
        suggestions = {
            "冲突/转折": "有什么让你意外或出乎意料的地方吗？",
            "情绪/感受": "当时/现在是什么感受？",
            "洞察/观点": "你觉得背后的原因/本质是什么？",
            "具体细节": "能具体描述一下当时的场景吗？"
        }
        
        if missing:
            return suggestions.get(missing[0], "还有什么想补充的吗？")
        return "素材收集完整，可以开始生成文章了"
    
    def to_summary(self) -> str:
        """输出素材摘要"""
        summary = f"""
## 访谈素材摘要

**话题**: {self.topic}
**类型**: {self.topic_type}
**访谈轮次**: {self.round_count}

### 核心观点
{self.core_viewpoint or "待提炼"}

### 收集到的要素

**冲突/转折** ({len(self.conflicts)}个):
{chr(10).join(['- ' + c for c in self.conflicts]) or '- 暂无'}

**情绪/感受** ({len(self.emotions)}个):
{chr(10).join(['- ' + e for e in self.emotions]) or '- 暂无'}

**洞察/观点** ({len(self.insights)}个):
{chr(10).join(['- ' + i for i in self.insights]) or '- 暂无'}

**具体细节** ({len(self.details)}个):
{chr(10).join(['- ' + d for d in self.details]) or '- 暂无'}

**金句素材** ({len(self.quotes)}个):
{chr(10).join(['- "' + q + '"' for q in self.quotes]) or '- 暂无'}

### 就绪检查
{json.dumps(self.check_readiness(), ensure_ascii=False, indent=2)}
"""
        return summary
    
    def export_json(self) -> str:
        """导出为JSON"""
        return json.dumps(asdict(self), ensure_ascii=False, indent=2)


def demo():
    """演示用法"""
    state = InterviewState()
    
    # 模拟访谈过程
    state.topic = "Manus被Meta收购"
    state.topic_type = "热点事件"
    
    # 第1轮
    state.round_count = 1
    state.add_emotion("震惊、五味杂陈")
    state.add_conflict("期望独立上市 vs 实际被收购")
    
    # 第2轮
    state.round_count = 2
    state.add_detail("地铁上刷到新闻，差点坐过站")
    state.add_insight("这是创业者的另一种选择")
    
    # 第3轮
    state.round_count = 3
    state.add_quote("放弃做产品，结果产品自己长出来了")
    state.core_viewpoint = "创业不是只有上市一条路，被收购也是一种成功"
    
    print(state.to_summary())
    print("\n建议下一个问题:", state.suggest_next_question())


if __name__ == "__main__":
    demo()
